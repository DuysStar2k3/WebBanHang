<p class="font-size-24 mg-5">Thêm danh mục bài viết</p>
<div class="main-item bg-main-item">
    <table class="danhmuc-add">
        <form method="post" action="modules/quanlydmbviet/xuly.php">
            <tr>
                <th>Điền danh mục</th>
            </tr>
            <tr>
                <td>Tên danh mục</td>
                <td><input type="text" name="tendanhmucbv"></td>
            </tr>
            <tr>
                <td>Thứ tự</td>
                <td><input type="number" name="thutubv"></td>
            </tr>
            <tr>
                <td colspan="2"><input type="submit" name="themdanhmucbv" value="Thêm danh mục bài viết"></td>
            </tr>
        </form>
    </table>
</div>